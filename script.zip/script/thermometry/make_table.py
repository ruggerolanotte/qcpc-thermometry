#!/usr/bin/env python3
"""Build bounds.tex from exact_results.json (exact.py: component distances)
and results.json (certify.py: same-rule certificates for the component and
for the monitored system).  All values are rounded upwards to a multiple of
1e-6 (exact distances are known within 1e-12).  Missing entries: --."""
from fractions import Fraction as F
import json
from pathlib import Path
here = Path(__file__).parent
cert = json.loads((here / 'results.json').read_text())
exact = json.loads((here / 'exact_results.json').read_text())

def up(x):
    k = (x.numerator * 10 ** 6 + x.denominator - 1) // x.denominator
    return f'{k / 10 ** 6:.6f}'

def nearest(x):
    k = (2 * x.numerator * 10 ** 6 + x.denominator) // (2 * x.denominator)
    return f'{k / 10 ** 6:.6f}'

def find(rows, **kw):
    for r in rows:
        if all(r.get(k) == v for k, v in kw.items()):
            return r
    return None

Ns = (1, 2)
lines = ['\\begin{tabular}{l' + 'rrr' * len(Ns) + '}\\toprule',
         ' & ' + ' & '.join(f'\\multicolumn{{3}}{{c}}{{$N={n}$}}' for n in Ns) + '\\\\',
         'Comparison & ' + ' & '.join('$\\db$ & $U_{\\mathrm{c}}$ & $U_{\\mathrm{s}}$' for _ in Ns)
         + '\\\\\\midrule']
for par in ['0', '1/100', '1/40', '1/20', 'report-tick reset']:
    label = f'$r_\\epsilon={par}$' if par != 'report-tick reset' else 'Environmental reset'
    cells = []
    for n in Ns:
        e = find(exact, parameter=par, cycles=n)
        # identical systems: d_b = 0 by reflexivity
        cells.append(up(F(e['upper_exact'])) if e else '0.000000' if par == '0' else '--')
        for system in (False, True):
            c = find(cert, parameter=par, cycles=n, system=system)
            cells.append(up(F(c['upper_exact'])) if c else '--')
    lines.append(label + ' & ' + ' & '.join(cells) + '\\\\')
lines.append('\\bottomrule\\end{tabular}')
(here / 'bounds.tex').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
