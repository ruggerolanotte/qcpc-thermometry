#!/usr/bin/env python3
"""Environmental coherence is not observable (Appendix B, memory witness).

For the nominal zone, compares the initial state |0><0|_q (x) |+><+|_e with
|0><0|_q (x) I/2_e, in the persistent and in the reset variant, and prints
the exact behavioural distance (expected: 0).  Usage: coherence.py [N ...]
"""
import sys
from pathlib import Path
from fractions import Fraction as F
sys.path.insert(0, str(Path(__file__).parent))
import model as M
from exact import Exact

def mixed_env():
    r = [M.Z] * 16
    for e in range(2):
        r[4 * e + e] = (F(1, 2), F(0))
    return tuple(r)

def main(Ns):
    for N in Ns:
        for reset in (False, True):
            S = M.System([M.Zone(reset=reset)], False)
            z = list(M.zone_init(N)); z[5] = mixed_env()
            v = Exact(S, S).d(S.init(N), ((tuple(z),), None))
            print(f'N={N} reset={reset}: d = {v}', flush=True)
            assert v == 0

if __name__ == '__main__':
    main(tuple(int(a) for a in sys.argv[1:]) or (1,))
