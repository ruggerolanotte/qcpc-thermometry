"""Exact semantics of the thermometry case study (Section 6).

A system consists of K thermometer zones with disjoint allocations
(probe q_k, environmental spin e_k, temperature, heater, mode, run flag),
optionally composed with the diagnostic monitor and restricted on the report
channels c_1..c_K.  Density matrices are 4x4 per zone (the zones stay in a
product state, Lemma normalisation-composition), with entries pairs of exact
fractions.  Standard library only.
"""
from arithmetic import F
from math import isqrt
import json
from pathlib import Path

# ------------------------------------------------------------ arithmetic
Z = (F(0), F(0)); ONE = (F(1), F(0)); II = (F(0), F(1))
def add(a, b): return (a[0] + b[0], a[1] + b[1])
def sub(a, b): return (a[0] - b[0], a[1] - b[1])
def mul(a, b): return (a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0])
def conj(a): return (a[0], -a[1])
def scale(a, p): return (a[0] * p, a[1] * p)
def cayley(t): return ((1 - t * t) / (1 + t * t), 2 * t / (1 + t * t))
def diag(r, d):
    return tuple(mul(mul(d[i], r[4 * i + j]), conj(d[j])) for i in range(4) for j in range(4))
def had(r):
    out = []
    for i in range(4):
        qi, ei = divmod(i, 2)
        for j in range(4):
            qj, ej = divmod(j, 2); v = Z
            for a in range(2):
                for b in range(2):
                    v = add(v, scale(r[4 * (2 * a + ei) + 2 * b + ej], F((-1) ** (qi * a + qj * b), 2)))
            out.append(v)
    return tuple(out)
def resetq(r):
    out = [Z] * 16
    for e in range(2):
        for f in range(2):
            out[4 * e + f] = add(r[4 * e + f], r[4 * (2 + e) + 2 + f])
    return tuple(out)
def resete(r):
    q = [add(r[4 * (2 * a) + 2 * b], r[4 * (2 * a + 1) + 2 * b + 1]) for a in range(2) for b in range(2)]
    return tuple(scale(q[2 * (i // 2) + j // 2], F(1, 2)) for i in range(4) for j in range(4))
def marginal(r):
    return [add(r[4 * (2 * a) + 2 * b], r[4 * (2 * a + 1) + 2 * b + 1]) for a in range(2) for b in range(2)]
def sqrtup(x):
    s = 10 ** 12
    k = isqrt((x.numerator * s * s) // x.denominator)
    if F(k * k, s * s) < x: k += 1
    return F(k, s)
def measure(r, b):
    p = sum((r[4 * i + i][0] for i in range(2 * b, 2 * b + 2)), F(0))
    if not p: return p, None
    return p, tuple(scale(r[4 * i + j], 1 / p) if i // 2 == b and j // 2 == b else Z
                    for i in range(4) for j in range(4))

PARAM = json.loads((Path(__file__).parent / 'parameters.json').read_text())
PHASE = [F(x, 10 ** 6) for x in PARAM['phase_cayley_numerators']]
bath = cayley(F(1, 8)); W = (conj(bath), bath, bath, conj(bath))
def tick(r, i):
    """E_i: W, then the temperature phase V_i, then residual dephasing."""
    phase = cayley(PHASE[i]); d = (W[0], W[1], mul(W[2], phase), mul(W[3], phase))
    r = diag(r, d)
    return tuple(scale(r[4 * a + b], F(49, 50)) if a // 2 != b // 2 else r[4 * a + b]
                 for a in range(4) for b in range(4))
def thermal(i, a):
    drift = 20 * a - i
    if not drift: return [(i, F(1))]
    p = F(abs(drift), 100)
    return [(i, 1 - p), (i + (1 if drift > 0 else -1), p)]
def rho0():
    """|0><0|_q (x) |+><+|_e"""
    r = [Z] * 16
    for e in range(2):
        for f in range(2): r[4 * e + f] = (F(1, 2), F(0))
    return tuple(r)

# -------------------------------------------------------------- zones
class Zone:
    """Parameters of one zone: readout phase error r_eps, environmental reset."""
    def __init__(self, eps=F(0), reset=False):
        self.eps = eps; self.reset = reset
        self.sphase = mul(II, cayley(eps))
    def S(self, r):
        return diag(r, (ONE, ONE, self.sphase, self.sphase))
    def __repr__(self): return f'Zone({self.eps},{self.reset})'

# zone state: (pc, i, a, m, run, rho);  pc encodes the continuation of
# Ctrl = D^N(act(run,0).nil).  The second slot of pc counts the remaining
# decisions; the third slot is unused (always 0).
def zone_init(N): return (('P', N, 0), 10, 0, 0, 1, rho0())

def zone_tau(zone, z):
    """Internal steps of a zone that do not involve communication."""
    pc, i, a, m, run, r = z; k = pc[0]
    def det(pc2, i=i, a=a, m=m, run=run, r=r): return [(F(1), (pc2, i, a, m, run, r))]
    if k == 'P':
        h, u = pc[1], pc[2]
        return [det(('nil',), run=0)] if h == 0 else [det(('S1r', h, u), m=0)]
    if k in ('S1r', 'S2r'): return [det((k[:2] + 'h',) + pc[1:], r=resetq(r))]
    if k in ('S1h', 'S2h'): return [det((k[:2] + 't',) + pc[1:], r=had(r))]
    if k in ('S1s', 'S2s'): return [det((k[:2] + 'H',) + pc[1:], r=zone.S(r))]
    if k in ('S1H', 'S2H'): return [det((k[:2] + 'm',) + pc[1:], r=had(r))]
    if k in ('S1m', 'S2m'):
        br = []
        for b in (0, 1):
            p, x = measure(r, b)
            if not p: continue
            if k == 'S1m':
                pc2 = ('S2r', pc[1], pc[2], b)
            else:   # if x=y then act(a,x).R else R  (guard resolved by nf)
                j = pc[3] + b
                pc2 = ('Ra' if pc[3] == b else 'Rm', pc[1], pc[2], j)
            br.append((p, (pc2, i, a, m, run, x)))
        return [br]
    if k == 'Ra':   # act(a,x) with x = y = j/2
        return [det(('Rm', pc[1], pc[2], pc[3]), a=pc[3] // 2)]
    if k == 'Rm': return [det(('Rc', pc[1], pc[2], pc[3]), m=1)]
    return []

def zone_report(z):
    """Value offered on the report channel, or None."""
    return z[0][3] if z[0][0] == 'Rc' else None

def zone_after_report(z):
    pc = z[0]; return (('Rt', pc[1], pc[2]),) + z[1:]

def zone_can_tick(z): return z[0][0] in ('S1t', 'S2t', 'Rc', 'Rt', 'nil', 'Wt')

def zone_tick(zone, z):
    pc, i, a, m, run, r = z; k = pc[0]
    pc2 = {'S1t': ('S1s',) + pc[1:], 'S2t': ('S2s',) + pc[1:]}.get(k)
    if k in ('Rc', 'Rt'): pc2 = ('P', pc[1] - 1, pc[2])
    if k == 'nil': pc2 = pc
    if k == 'Wt': pc2 = ('P', 0, 0)
    if run == 0: return [(F(1), (pc2, i, a, m, run, r))]
    r2 = tick(r, i)
    if zone.reset and m == 1: r2 = resete(r2)
    return [(w, (pc2, j, a, m, run, r2)) for j, w in thermal(i, a)]

# -------------------------------------------------------------- monitor
# states: ('X',) waits c_1; ('X1', z1) waits c_2; ('X2', g) offers notify!g;
# ('Xt',) = tick.X.  Every state can tick: the first three time out to X.
def g(z1, z2): return int(z1 == 2) + int(z2 == 2)

# -------------------------------------------------------------- systems
class System:
    def __init__(self, zones, monitor):
        self.zones = tuple(zones); self.monitor = monitor
        assert not monitor or len(zones) == 2
    def init(self, N):
        return (tuple(zone_init(N) for _ in self.zones), ('X',) if self.monitor else None)

    def steps(self, s):
        """All strong transitions (label, [(prob, state)]).  Labels: 'tau',
        'tick', ('c', k, v) for an unrestricted report, ('notify', v)."""
        zs, mon = s; out = []
        for k, (zone, z) in enumerate(zip(self.zones, zs)):
            for tgt in zone_tau(zone, z):
                out.append(('tau', [(p, (zs[:k] + (z2,) + zs[k + 1:], mon)) for p, z2 in tgt]))
            v = zone_report(z)
            if v is not None:
                zs2 = zs[:k] + (zone_after_report(z),) + zs[k + 1:]
                if not self.monitor:
                    out.append((('c', k, v), [(F(1), (zs2, mon))]))
                elif (k == 0 and mon == ('X',)):
                    out.append(('tau', [(F(1), (zs2, ('X1', v)))]))
                elif (k == 1 and mon[0] == 'X1'):
                    out.append(('tau', [(F(1), (zs2, ('X2', g(mon[1], v))))]))
        if self.monitor and mon[0] == 'X2':
            out.append((('notify', mon[1]), [(F(1), (zs, ('Xt',)))]))
        if all(zone_can_tick(z) for z in zs):
            mon2 = ('X',) if self.monitor else None
            dist = [(F(1), ())]
            for zone, z in zip(self.zones, zs):
                dist = [(p * q, t + (z2,)) for p, t in dist for q, z2 in zone_tick(zone, z)]
            out.append(('tick', [(p, (t, mon2)) for p, t in dist]))
        return out

def frozen(s):
    zs, mon = s
    return all(z[0][0] == 'nil' and z[4] == 0 for z in zs) and mon in (None, ('X',))

# -------------------------------------------------------- observations
def zone_obs(z1, z2, up=True):
    t = min(F(1), F(abs(z1[1] - z2[1]), 20))
    aa = F(abs(z1[2] - z2[2]))
    a = marginal(z1[5]); b = marginal(z2[5])
    x = sub(a[0], b[0])[0]; y = sub(a[1], b[1])
    s2 = x * x + y[0] * y[0] + y[1] * y[1]
    tr = min(F(1), sqrtup(s2))
    return max(t, aa, tr)

def obs(s1, s2):
    """max over zones; the monitor, modes and run flags are not observed.
    Trace distances are rounded up by less than 1e-12."""
    return max(zone_obs(z1, z2) for z1, z2 in zip(s1[0], s2[0]))
