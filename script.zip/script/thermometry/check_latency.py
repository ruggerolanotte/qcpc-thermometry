"""Checks for the latency extension; does not replace the metric proofs."""
from arithmetic import F
from collections import deque
import model as M
from latency import Delayed, path, align
import json
from pathlib import Path

for delay in (0,1,2):
    sysm=Delayed(delay)
    todo=deque([(sysm.init(),0)]); seen=set(); transitions=0
    while todo:
        s,nt=todo.popleft()
        if (s,nt) in seen: continue
        seen.add((s,nt))
        if M.frozen(s):
            assert nt==5
            assert sysm.steps(s)==[('tick',[(F(1),s)])]
            continue
        z=s[0][0]
        for lab,tgt in sysm.steps(s):
            transitions+=1
            assert sum(p for p,t in tgt)==1
            assert all(p>0 for p,t in tgt)
            for p,t in tgt:
                w=t[0][0]
                assert 0<=w[1]<=20
                assert sum(w[5][4*k+k][0] for k in range(4))==1
                if lab=='tick':
                    assert w[6:]==(z[2],z[6])
                    assert w[5]==M.tick(z[5],z[1])
                    eff=(z[2],z[6],z[7])[delay]
                    assert (w[1],p) in M.thermal(z[1],eff)
                else:
                    assert w[6:]==z[6:]
                todo.append((t,nt+(lab=='tick')))
    print('delay',delay,':',len(seen),'states;',transitions,'transitions checked')
    p=path(sysm,{3+delay})
    assert [s[0][0][1] for s in p]==[10]*(3+delay)+[11]*(3-delay)
rows=json.loads(Path(__file__).with_name('latency_results.json').read_text())
for row in rows:
    matrix=[[F(v) for v in r] for r in row['matrix_upper']]
    assert align(matrix)==F(row['aligned_upper'])
    assert max(matrix[i][i] for i in range(6))==F(row['synchronous_upper'])
    assert F(row['synchronous_upper'])<F(1,5)
    assert F(row['initial_upper'])==matrix[0][0]
print('PASS: five enabled ticks, command latency, probability mass, quantum updates and alignment')
