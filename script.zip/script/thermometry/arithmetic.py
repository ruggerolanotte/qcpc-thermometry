"""Exact rationals. Standard-library default; optional GMP acceleration."""
import os
if os.environ.get('QCPC_GMP') == '1':
    from gmpy2 import mpq as F
else:
    from fractions import Fraction as F
