"""Regression and exact LP comparisons for the corrected two-atom solver."""
from arithmetic import F
import random
from exact import two_atom_value, lp_min

def compare(distributions,p,d1,d2):
    n=len(d1); m=len(distributions)
    nodes=[['root','pre',[],False,False]]
    for dist in distributions:
        kids=[]
        for x,w in enumerate(dist):
            if w:
                kids.append((w,len(nodes)))
                nodes.append([x,'post',[],True,False])
        nodes[0][2].append(kids)
    result=two_atom_value(nodes,p,dict(enumerate(d1)),dict(enumerate(d2)))
    # Variables: resolution weights, transport from atom 1, transport from atom 2.
    cost=[F(0)]*m+d1+d2
    rows=[{i:F(1) for i in range(m)}, {m+i:F(1) for i in range(n)},
          {m+n+i:F(1) for i in range(n)}]; rhs=[F(1),p,1-p]
    for x in range(n):
        row={m+x:F(1),m+n+x:F(1)}
        row.update({j:-distributions[j][x] for j in range(m)})
        rows.append(row);rhs.append(F(0))
    expected=lp_min(cost,rows,rhs)
    assert result==expected,(result,expected,distributions,p,d1,d2)
    return result

assert compare([[F(1),F(0)],[F(0),F(1)]],F(1,2),
               [F(1,5),F(4,5)],[F(4,5),F(1,5)])==F(1,5)
r=random.Random(20261026)
for k in range(150):
    n=r.randint(2,4);m=r.randint(1,4);dist=[]
    for j in range(m):
        weights=[r.randint(1,9) for i in range(n)]
        dist.append([F(w,sum(weights)) for w in weights])
    compare(dist,F(r.randint(1,9),10),[F(r.randint(0,10),10) for i in range(n)],
            [F(r.randint(0,10),10) for i in range(n)])
print('PASS: missed-intersection regression and 150 exact rational flow-LP comparisons')
