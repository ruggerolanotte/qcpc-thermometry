"""Independent matrix checks; optional NumPy dependency, not used by certify.py."""
import numpy as np
from fractions import Fraction as F
import model as c   # was: certify (stale names)

def matrix(r):return np.array([complex(float(x),float(y)) for x,y in r]).reshape(4,4)
def ptrq(r):return np.trace(r.reshape(2,2,2,2),axis1=1,axis2=3)
def ptre(r):return np.trace(r.reshape(2,2,2,2),axis1=0,axis2=2)
H=np.kron(np.array([[1,1],[1,-1]])/np.sqrt(2),np.eye(2))
Z=np.kron(np.diag([1,-1]),np.eye(2))
plus=np.ones((2,2))/2
r=c.had(c.rho0())
for i in (0,3,10,17,20):
    R=matrix(r)
    assert np.allclose(matrix(c.had(r)),H@R@H)
    assert np.allclose(matrix(c.resetq(r)),np.kron(np.diag([1,0]),ptre(R)))
    assert np.allclose(matrix(c.resete(r)),np.kron(ptrq(R),plus))
    theta=2*np.arctan(1/8)
    phase=2*np.arctan(float(c.PHASE[i]))
    D=np.diag(np.exp(-1j*theta*np.array([1,-1,-1,1])))
    D=np.diag([1,1,np.exp(1j*phase),np.exp(1j*phase)])@D
    expected=.99*(D@R@D.conj().T)+.01*(Z@D@R@D.conj().T@Z)
    out=c.tick(r,i)
    assert np.allclose(matrix(out),expected)
    assert sum((out[4*k+k][0] for k in range(4)),F(0))==1
    assert np.linalg.eigvalsh(matrix(out)).min()>-1e-12
    for b in (0,1):
        p,t=c.measure(c.had(out),b)
        P=np.diag([int(k//2==b) for k in range(4)])
        raw=P@H@expected@H@P
        assert abs(float(p)-np.trace(raw).real)<1e-12
        if p:assert np.allclose(matrix(t),raw/float(p))
    diff=ptrq(matrix(out))-ptrq(R)
    d=np.abs(np.linalg.eigvalsh(diff)).sum()/2
    zone=lambda x:(('P',0,0),10,0,0,1,x)
    assert float(c.zone_obs(zone(out),zone(r)))+2e-15>=d
    r=out
for i in range(21):
    for a in (0,1):
        branches=c.thermal(i,a)
        assert sum((p for _,p in branches),F(0))==1
        assert sum((j*p for j,p in branches),F(0))==F(i)+F(20*a-i,100)
for x in [F(0),F(1),F(1,3),F(7,19),F(10**30+1,10**31)]:
    u=c.sqrtup(x)
    assert u*u>=x and (u==0 or (u-F(1,10**12))**2<x)
print('PASS: independent dense-matrix checks, trace/positivity, measurement probabilities, thermal means, outward rounding.')
