"""Certified jitter witness after the last probe measurement.

The probe stays in |1>; only ticks and the final act(run,0) remain.
The latter is observationally inert. A state (h,i) has h enabled ticks
remaining and temperature index i. Frozen states have h=0.
This backward cost supplies weak matching certificates on the full tail.
All thermal probabilities and costs below are exact rationals.
"""
from arithmetic import F
from functools import lru_cache
from pathlib import Path
import json
import model as M
from latency import Delayed

class Jitter(Delayed):
    def __init__(self): super().__init__(0)
    def steps(self,s):
        out=super().steps(s)
        if s[0][0][0][0] in ('Rc','Rt'):
            out=[(lab,[(p,((((('Tail',20),)+x[0][0][1:]),),x[1]))
                         for p,x in tgt]) if lab=='tick' else (lab,tgt)
                 for lab,tgt in out]
        return out

def witness(jump):
    system=Jitter(); s=system.init(); samples=[s]; t=0
    while not M.frozen(s):
        steps=system.steps(s)
        internal=[target for lab,target in steps if lab=='tau']
        reports=[target for lab,target in steps if isinstance(lab,tuple)]
        if internal:
            p,s=internal[0][-1] # choose measurement result 1
        elif reports:
            p,s=reports[0][0]
        else:
            target=next(target for lab,target in steps if lab=='tick')
            t+=1; desired=10 if t<jump else 11
            p,s=next((p,x) for p,x in target if x[0][0][1]==desired)
            samples.append(s)
        assert p>0
    assert t==23
    expected=[M.Z,M.Z,M.Z,M.ONE]
    assert all(M.marginal(x[0][0][5])==expected for x in samples[3:])
    return samples

def successors(h, i):
    return [(p,(h-1,j)) for j,p in M.thermal(i,1)] if h else [(F(1),(0,i))]

def transport(a,b):
    if len(a)==1:
        return sum(q*bound(*a[0][1],*y) for q,y in b)
    if len(b)==1:
        return sum(p*bound(*x,*b[0][1]) for p,x in a)
    p,x=a[0]; _,xx=a[1]; q,y=b[0]; _,yy=b[1]
    c00=bound(*x,*y); c01=bound(*x,*yy)
    c10=bound(*xx,*y); c11=bound(*xx,*yy)
    lo=max(F(0),p+q-1); hi=min(p,q)
    z=lo if c00-c01-c10+c11>=0 else hi
    return z*c00+(p-z)*c01+(q-z)*c10+(1-p-q+z)*c11

@lru_cache(None)
def bound(h,i,k,j):
    o=F(abs(i-j),20)
    if h==k and i==j: return F(0)
    if h==k==0: return o
    return max(o,transport(successors(h,i),successors(k,j)))

def run():
    T=23
    lp=witness(4); rp=witness(5)
    assert lp[:4]==rp[:4]
    # The first three ticks follow the same nominal decision: both outcomes
    # are 1, the report succeeds, and temperature stays at index 10.
    # The heater is now on. The only chosen thermal increase is tick 4/5.
    left=[10 if t<4 else 11 for t in range(T+1)]
    right=[10 if t<5 else 11 for t in range(T+1)]
    for seq in (left,right):
        for t in range(4,T+1):
            assert dict(M.thermal(seq[t-1],1))[seq[t]]>0
    alignment=[(0,0),(1,1),(2,2),(3,3),(3,4)]
    alignment += [(i,i+1) for i in range(4,T)]
    alignment += [(T,T)]
    diagonal=max(bound(T-i,left[i],T-i,right[i]) for i in range(3,T+1))
    state_upper=max(bound(T-i,left[i],T-j,right[j]) for i,j in alignment if i>=3)
    timed=max(state_upper,F(1,T))
    assert diagonal==F(1,20)
    assert state_upper<=F(1,T)<diagonal
    # Every non-diagonal alignment has temporal cost at least 1/T;
    # the diagonal costs at least 1/20 by its temperature observation.
    row=dict(ticks=T,tail_ticks=20,diagonal_exact=str(diagonal),
             aligned_exact=str(timed),state_upper=str(state_upper),
             left=left,right=right,alignment=alignment,pairs=bound.cache_info().currsize)
    Path(__file__).with_name('jitter_results.json').write_text(json.dumps(row,indent=2)+'\n')
    print(json.dumps(row),flush=True)

if __name__=='__main__': run()
