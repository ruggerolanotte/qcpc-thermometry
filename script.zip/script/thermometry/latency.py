"""One decision, two additional ticks; actuator latency 0, 1, 2 ticks.
Uses the existing strong semantics and exact weak-response solver.
The two last sampled commands are unobserved physical variables.
"""
from arithmetic import F
import json, time
from pathlib import Path
import model as M
from exact import Exact, ETA

class Delayed(M.System):
    def __init__(self, delay):
        super().__init__([M.Zone()], False)
        assert delay in (0,1,2)
        self.delay=delay
    def init(self, N=1):
        assert N==1
        return ((M.zone_init(1)+(0,0),),None)
    def steps(self,s):
        zs,mon=s; z=zs[0]; pc,i,a,m,run,r,b1,b2=z
        core=z[:6]
        # Final continuation: tick.tick.act(run,0).nil.
        if pc[0]=='P' and pc[1]==0:
            return [('tau',[(F(1),(((('nil',),i,a,m,0,r,b1,b2),),None))])]
        out=[]
        if pc[0]!='Tail':
            for lab,tgt in super().steps(((core,),None)):
                if lab!='tick':
                    out.append((lab,[(p,((t[0][0]+(b1,b2),),None)) for p,t in tgt]))
        if pc[0]=='Tail' or M.zone_can_tick(core):
            if pc[0]=='Tail':
                pc2=('Tail',pc[1]-1) if pc[1]>1 else ('P',0,0)
            else:
                pc2=M.zone_tick(self.zones[0],core)[0][1][0]
                if pc[0] in ('Rc','Rt'): pc2=('Tail',2)
            if not run:
                tgt=[(F(1),(((pc2,i,a,m,run,r,b1,b2),),None))]
            else:
                effective=(a,b1,b2)[self.delay]
                r2=M.tick(r,i)
                tgt=[(p,(((pc2,j,a,m,run,r2,a,b1),),None)) for j,p in M.thermal(i,effective)]
            out.append(('tick',tgt))
        return out

def path(sysm, heating_ticks):
    s=sysm.init(); samples=[s]; tickno=0
    while not M.frozen(s):
        steps=sysm.steps(s)
        tau=[t for l,t in steps if l=='tau']
        if tau:
            tgt=tau[0]
            # Select outcome 1 in each measurement (all selected masses >0).
            s=tgt[-1][1]
            continue
        reports=[t for l,t in steps if isinstance(l,tuple)]
        if reports:
            s=reports[0][0][1]; continue
        tgt=next(t for l,t in steps if l=='tick'); tickno+=1
        # Choose a temperature increase on declared ticks, otherwise stay.
        old=s[0][0][1]
        preferred=old+1 if tickno in heating_ticks else old
        chosen=[x for p,x in tgt if x[0][0][1]==preferred]
        assert chosen, (tickno,preferred)
        s=chosen[0]; samples.append(s)
    assert len(samples)==6
    return samples

def align(matrix):
    T=len(matrix)-1; dp={}
    for i in range(T+1):
        for j in range(T+1):
            cost=max(F(abs(i-j),T),matrix[i][j])
            prev=[dp[k] for k in ((i-1,j),(i,j-1),(i-1,j-1)) if k in dp]
            dp[i,j]=max(cost,min(prev)) if prev else cost
    return dp[T,T]

def run():
    rows=[]
    for delay in (1,2):
        start=time.time(); L=Delayed(0); R=Delayed(delay)
        ex=Exact(L,R)
        # Equal measurement outcomes; the heating move occurs later on the right.
        p=path(L,{3}); q=path(R,{3+delay})
        print('start delay',delay,flush=True)
        initial=ex.d(p[0],q[0]); print('initial',float(initial),'pairs',len(ex.memo),flush=True)
        mat=[[ex.d(x,y) for y in q] for x in p]
        sync=max(mat[i][i] for i in range(6)); ds=align(mat)
        row=dict(delay=delay,ticks=5,initial_upper=str(initial),initial_lower=str(max(F(0),initial-ETA)),
                 synchronous_upper=str(sync),aligned_upper=str(ds),aligned_lower=str(max(F(0),ds-ETA)),
                 matrix_upper=[[str(v) for v in rr] for rr in mat],
                 left_temperatures=[x[0][0][1] for x in p],right_temperatures=[x[0][0][1] for x in q],
                 pairs=len(ex.memo),seconds=time.time()-start)
        rows.append(row)
        Path(__file__).with_name('latency_results.json').write_text(json.dumps(rows,indent=2)+'\n')
        print('finished',delay,float(sync),float(ds),len(ex.memo),flush=True)
if __name__=='__main__': run()
