#!/usr/bin/env python3
"""Run the thermometry experiments from quantum_CPS(10).

Place beside model.py in script/thermometry/, or at the paper root.
Usage: python3 runall.py [all|quick|checks|table] [--list] [--gmp]

all (default): exact component intervals N=1,2; component certificates
N=1,2,3; monitored certificates N=1 and the identical N=2 baseline;
environmental coherence N=1,2; delay, jitter, checks and table.
quick: short validation runs and jitter; no full distance table.
checks: validations only (check_latency reads the supplied latency results).
table: regenerate bounds.tex from existing exact_results.json and results.json.
--list: print commands and outputs without executing them.
--gmp: use optional gmpy2. Only the dense-matrix check requires NumPy.
"""
import argparse
import importlib.util
import os
from pathlib import Path
import shlex
import subprocess
import sys


def jobs(mode):
    checks = [
        ('exact.py --check', 'stdout: transport checks and memory witness'),
        ('test_dual.py', 'stdout: two-atom optimisation checks'),
        ('check.py', 'stdout: dense-matrix checks'),
        ('check_latency.py', 'stdout: delay checks using latency_results.json'),
    ]
    table = [('make_table.py', 'bounds.tex (N=1,2)')]
    if mode == 'checks':
        return checks
    if mode == 'table':
        return table
    if mode == 'quick':
        return checks + [('jitter.py', 'jitter_results.json')]
    return ([(f'exact.py {n}', 'exact_results.json: component distance intervals')
             for n in (1, 2)]
            + [(f'certify.py {n} component', 'results.json: component upper bounds')
               for n in (1, 2, 3)]
            + [('certify.py 1 system', 'results.json: monitored upper bounds'),
               ('certify.py 2 system 0', 'results.json: identical-system baseline'),
               ('coherence.py 1 2', 'stdout: environmental coherence comparisons'),
               ('latency.py', 'latency_results.json'),
               ('jitter.py', 'jitter_results.json')]
            + checks + table)


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('mode', choices=('all', 'quick', 'checks', 'table'),
                        default='all', nargs='?')
    parser.add_argument('--list', action='store_true')
    parser.add_argument('--gmp', action='store_true')
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    roots = (here, here / 'script' / 'thermometry')
    base = next((p for p in roots if (p / 'model.py').is_file()), None)
    if base is None:
        parser.error('Place runall.py beside model.py or in the paper root.')
    steps = jobs(args.mode)
    env = os.environ.copy()
    if args.gmp:
        env['QCPC_GMP'] = '1'
    if not args.list:
        required = (['numpy'] if any(c == 'check.py' for c, _ in steps) else [])
        if env.get('QCPC_GMP') == '1':
            required.append('gmpy2')
        for pkg in required:
            if importlib.util.find_spec(pkg) is None:
                parser.error(f'Missing dependency: {pkg}. Install it for this Python interpreter.')
    for command, output in steps:
        parts = shlex.split(command)
        print(f'{command}  ->  {output}', flush=True)
        if not args.list:
            subprocess.run([sys.executable, str(base / parts[0]), *parts[1:]],
                           cwd=base, env=env, check=True)


if __name__ == '__main__':
    main()
