#!/usr/bin/env python3
"""Exact behavioural distance d_b between two thermometer components.

The fixed-point equation  d(C,D) = max{ dO(C,D), F(d)(C,D) }  is solved over
ALL pairs of reachable configurations, minimising over ALL combined weak
responses, encoded as randomised resolutions of the finite response tree
(Lemma weak-trees).  Visible reports c!v are challenges; a stable response
that cannot perform the same report fails (cost 1 against live mass).

The protocol ends in frozen configurations whose only transition is a tick
to themselves; there d_b is the observation distance.  Every other pair
depends only on pairs of smaller total remaining length, so the recursion
computes the least fixed point.  Observation costs exceed the true ones by
less than ETA = 1e-12 (trace distances rounded up) and the least fixed point
is 1-Lipschitz in the observation term, so the result v satisfies
v - ETA <= d_b <= v.  All other arithmetic is exact.  Standard library only.
"""
from arithmetic import F
import json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import model as M

sys.setrecursionlimit(100000)
ETA = F(1, 10 ** 12)
BOT = 'BOT'

# ---------------------------------------------------------------- exact LP
def lp_min(cost, rows, rhs):
    """min cost.x s.t. rows x = rhs, x >= 0; exact two-phase simplex (Bland)."""
    n = len(cost); m = len(rows); T = []
    for r, b in zip(rows, rhs):
        sgn = -1 if b < 0 else 1
        row = [F(0)] * (n + m + 1)
        for j, v in r.items(): row[j] = sgn * v
        row[-1] = sgn * b; T.append(row)
    for i in range(m): T[i][n + i] = F(1)
    basis = [n + i for i in range(m)]
    def pivot(pr, pc):
        piv = T[pr][pc]; T[pr] = [v / piv for v in T[pr]]
        for i in range(m):
            if i != pr and T[i][pc] != 0:
                f = T[i][pc]; T[i] = [a - f * b for a, b in zip(T[i], T[pr])]
        basis[pr] = pc
    def run(obj, allowed):
        while True:
            best = None
            for j in range(n + m):
                if not allowed[j] or j in basis: continue
                if obj[j] - sum(obj[basis[i]] * T[i][j] for i in range(m)) < 0:
                    best = j; break
            if best is None: return
            pr = None; ratio = None
            for i in range(m):
                if T[i][best] > 0:
                    q = T[i][-1] / T[i][best]
                    if ratio is None or q < ratio or (q == ratio and basis[i] < basis[pr]):
                        ratio = q; pr = i
            if pr is None: raise RuntimeError('unbounded')
            pivot(pr, best)
    run([F(0)] * n + [F(1)] * m, [True] * (n + m))
    if sum(T[i][-1] for i in range(m) if basis[i] >= n) != 0: raise RuntimeError('infeasible')
    for i in range(m):
        if basis[i] >= n:
            for j in range(n):
                if T[i][j] != 0: pivot(i, j); break
    obj2 = list(cost) + [F(0)] * m
    run(obj2, [True] * n + [False] * m)
    return sum(obj2[basis[i]] * T[i][-1] for i in range(m))

# ------------------------------------------------------- response trees
def tree(sysm, root, label):
    """Nodes [state, phase, options, can_stop, fails] of the tree of weak
    `label` responses from root.  Failure leaves end in BOT."""
    nodes = []
    def add(s, ph): nodes.append([s, ph, [], False, False]); return len(nodes) - 1
    stack = [add(root, 'pre')]
    while stack:
        v = stack.pop(); s, ph = nodes[v][0], nodes[v][1]
        opts = []; has_tau = False; has_lab = False
        for lab, tgt in sysm.steps(s):
            if lab == 'tau':
                has_tau = True
                kids = [(p, add(x, ph)) for p, x in tgt]
                opts.append(kids); stack.extend(k for _, k in kids)
            elif label != 'tau' and lab == label and ph == 'pre':
                has_lab = True
                kids = [(p, add(x, 'post')) for p, x in tgt]
                opts.append(kids); stack.extend(k for _, k in kids)
        nodes[v][2] = opts
        nodes[v][3] = (label == 'tau') or ph == 'post'
        nodes[v][4] = (label != 'tau' and ph == 'pre' and not has_tau and not has_lab)
    return nodes

class Exact:
    def __init__(self, L, R):
        self.L = L; self.R = R; self.memo = {}; self.pool = {}; self.tcache = {}; self.two = 0
    def intern(self, s): return self.pool.setdefault(s, s)
    def T(self, sysm, s, label):
        key = (id(sysm), s, label)
        if key not in self.tcache: self.tcache[key] = tree(sysm, s, label)
        return self.tcache[key]

    def d(self, cl, cr):
        cl = self.intern(cl); cr = self.intern(cr); key = (cl, cr)
        if key in self.memo: return self.memo[key]
        o = M.obs(cl, cr)
        if o == 1 or (M.frozen(cl) and M.frozen(cr)):
            self.memo[key] = o; return o
        self.memo[key] = None
        val = o
        for lab, tgt in self.L.steps(cl):
            val = max(val, self.match(tgt, self.R, cr, lab, True))
            if val == 1: break
        if val < 1:
            for lab, tgt in self.R.steps(cr):
                val = max(val, self.match(tgt, self.L, cl, lab, False))
                if val == 1: break
        self.memo[key] = val
        return val

    def cost(self, a, x, left):
        if x == BOT: return F(1)
        v = self.d(a, x) if left else self.d(x, a)
        assert v is not None, 'unexpected cycle'
        return v

    def dp(self, nodes, h):
        val = [None] * len(nodes)
        for v in reversed(range(len(nodes))):
            s, ph, opts, stop, fail = nodes[v]
            cands = [h[s]] if stop else []
            if fail: cands.append(h[BOT])
            for kids in opts: cands.append(sum(p * val[k] for p, k in kids))
            val[v] = min(cands)
        return val[0]

    def match(self, delta, sysm, resp, lab, left):
        """min over weak lab-responses Theta of resp of K(d)(delta, Theta).
        One atom: deterministic resolution (backward pass).  Two atoms: dual of
        the fractional knapsack and Sion's minimax theorem (Appendix B)."""
        nodes = self.T(sysm, resp, lab)
        xs = {n[0] for n in nodes if n[3]} | ({BOT} if any(n[4] for n in nodes) else set())
        if len(delta) == 1:
            a = delta[0][1]
            return self.dp(nodes, {x: self.cost(a, x, left) for x in xs})
        assert len(delta) == 2; self.two += 1
        (p1, a1), (p2, a2) = delta
        d1 = {x: self.cost(a1, x, left) for x in xs}
        d2 = {x: self.cost(a2, x, left) for x in xs}
        return two_atom_value(nodes, p1, d1, d2)


def two_atom_value(nodes, p, d1, d2):
    """Exact maximisation of the concave dual, including new intersections.

    Each oracle call selects an affine majorant from the response tree.
    The minimum of the selected lines bounds the entire dual from above.
    Stop only when an evaluated value reaches that upper bound.
    """
    def oracle(lam):
        vals = [None] * len(nodes)
        for v in reversed(range(len(nodes))):
            s, ph, opts, stop, fail = nodes[v]
            candidates = []
            for x in ([s] if stop else []) + ([BOT] if fail else []):
                candidates.append(min((d2[x], F(0)), (d1[x]-lam, F(-1))))
            for kids in opts:
                candidates.append((sum(w*vals[k][0] for w,k in kids),
                                   sum(w*vals[k][1] for w,k in kids)))
            vals[v] = min(candidates)
        value, slope = vals[0]
        return p*lam+value, p+slope

    lo = min(d1[x]-d2[x] for x in d1)
    hi = max(d1[x]-d2[x] for x in d1)
    lines = set(); lower = None
    def sample(x):
        nonlocal lower
        y, slope = oracle(x)
        lower = y if lower is None else max(lower,y)
        lines.add((slope,y-slope*x))
        return y
    sample(lo); sample(hi)
    while True:
        candidates = {lo,hi}
        ordered = sorted(lines)
        for i,(a,b) in enumerate(ordered):
            for c,d in ordered[i+1:]:
                if a != c:
                    x = (d-b)/(a-c)
                    if lo <= x <= hi: candidates.add(x)
        upper, x = max((min(a*x+b for a,b in lines),x) for x in candidates)
        if upper == lower:
            assert 0 <= lower <= 1
            return lower
        assert upper > lower
        old = len(lines)
        sample(x)
        assert len(lines)>old or lower==upper, 'dual refinement failed'

# ---------------------------------------------------------------- cases
CASES = [('phase', str(e), M.Zone(), M.Zone(eps=e)) for e in (F(0), F(1, 100), F(1, 40), F(1, 20))]
CASES.append(('bath_reset', 'report-tick reset', M.Zone(), M.Zone(reset=True)))

def run(N, only=None, out='exact_results.json'):
    rows = []
    for name, par, zl, zr in CASES:
        if only and par not in only: continue
        t = time.time()
        L = M.System([zl], False); R = M.System([zr], False)
        ex = Exact(L, R); up = ex.d(L.init(N), R.init(N)); lo = max(F(0), up - ETA)
        rows.append(dict(experiment=name, cycles=N, parameter=par,
                         lower_exact=str(lo), upper_exact=str(up),
                         lower_display=float(lo), upper_display=float(up),
                         pairs=len(ex.memo), two_atom_challenges=ex.two,
                         seconds=time.time() - t))
        print(N, name, par, float(lo), float(up), len(ex.memo), round(time.time() - t, 1), flush=True)
    path = Path(__file__).parent / out
    old = json.loads(path.read_text()) if path.exists() else []
    keys = {(r['cycles'], r['parameter']) for r in rows}
    path.write_text(json.dumps([r for r in old if (r['cycles'], r['parameter']) not in keys] + rows,
                               indent=2) + '\n')

def witness():
    """tick.act(run,0).nil, q in |+>, e in |b>, temperature T_*, heater off."""
    def st(b):
        r = [M.Z] * 16
        for qi in range(2):
            for qj in range(2): r[4 * (2 * qi + b) + 2 * qj + b] = (F(1, 2), F(0))
        return ((('Wt',), 10, 0, 0, 1, tuple(r)),), None
    S = M.System([M.Zone()], False)
    up = Exact(S, S).d(st(0), st(1))
    v = F(49, 50) * F(2016, 4225)
    assert v <= up < v + ETA, (float(up), float(v))
    print('memory witness: d_b =', v, '=', float(v))

def check(n=60, seed=1):
    """Compare the two-atom formula with the exact flow LP on sampled challenges."""
    import random
    random.seed(seed); done = [0]
    class V(Exact):
        def match(self, delta, sysm, resp, lab, left):
            val = super().match(delta, sysm, resp, lab, left)
            if len(delta) == 2 and done[0] < n and random.random() < 0.3:
                nodes = self.T(sysm, resp, lab); cost = []
                def nv(x): cost.append(x); return len(cost) - 1
                stopv = {}; failv = {}; optv = {}
                for v, (s, ph, opts, stop, fail) in enumerate(nodes):
                    if stop: stopv[v] = nv(F(0))
                    if fail: failv[v] = nv(F(0))
                    for t, _ in enumerate(opts): optv[(v, t)] = nv(F(0))
                xs = sorted({nodes[v][0] for v in stopv}, key=repr) + ([BOT] if failv else [])
                om = {(ai, xi): nv(self.cost(a, x, left))
                      for ai, (pa, a) in enumerate(delta) for xi, x in enumerate(xs)}
                rows = []; rhs = []; parent = {}
                for (v, t), j in optv.items():
                    for p, k in nodes[v][2][t]: parent.setdefault(k, []).append((j, p))
                for v in range(len(nodes)):
                    row = {}
                    if v in stopv: row[stopv[v]] = F(1)
                    if v in failv: row[failv[v]] = F(1)
                    for t in range(len(nodes[v][2])): row[optv[(v, t)]] = F(1)
                    for j, p in parent.get(v, []): row[j] = row.get(j, F(0)) - p
                    rows.append(row); rhs.append(F(1) if v == 0 else F(0))
                for ai, (pa, a) in enumerate(delta):
                    rows.append({om[(ai, xi)]: F(1) for xi in range(len(xs))}); rhs.append(pa)
                for xi, x in enumerate(xs):
                    row = {om[(ai, xi)]: F(1) for ai in range(len(delta))}
                    src = failv if x == BOT else {v: j for v, j in stopv.items() if nodes[v][0] == x}
                    for v, j in src.items(): row[j] = row.get(j, F(0)) - 1
                    rows.append(row); rhs.append(F(0))
                assert lp_min(cost, rows, rhs) == val
                done[0] += 1
            return val
    L = M.System([M.Zone()], False); R = M.System([M.Zone(eps=F(1, 40))], False)
    V(L, R).d(L.init(1), R.init(1))
    print('two-atom formula agrees with the exact flow LP on', done[0], 'challenges')

if __name__ == '__main__':
    args = sys.argv[1:]
    if args and args[0] == '--check':
        check(); witness()
    else:
        # usage: exact.py N [parameter ...], e.g. exact.py 2 1/20
        run(int(args[0]) if args else 1, set(args[1:]) or None)
