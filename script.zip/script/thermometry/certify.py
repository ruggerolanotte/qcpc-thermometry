#!/usr/bin/env python3
"""Upper certificates by same-rule matching (Proposition thermometry-certificate).

Each strong challenge is answered by the corresponding strong transition of
the other system (same rule, same component, same label).  Target atoms with
the same classical part are coupled with mass min(p,q); the residual mass is
charged 1.  Pairs reached through matched atoms again have equal classical
parts; mismatched continuations are not explored.  Frozen pairs receive their
observation distance.  The resulting cost is a certificate, so it bounds d_b
from above.  Exact arithmetic; trace distances rounded up.
"""
from arithmetic import F
import json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import model as M
sys.setrecursionlimit(100000)
if hasattr(sys, 'set_int_max_str_digits'):
    sys.set_int_max_str_digits(0)  # finite exact certificates can have long numerators

def classical(s):
    zs, mon = s
    return (tuple(z[:5] for z in zs), mon)

class Cert:
    def __init__(self, L, R):
        self.L = L; self.R = R; self.memo = {}
        self.same = repr(L.zones) == repr(R.zones)   # identical systems
    def u(self, cl, cr):
        key = (cl, cr)
        if key in self.memo: return self.memo[key]
        o = M.obs(cl, cr)
        if self.same and cl == cr: v = F(0)
        elif o == 1 or (M.frozen(cl) and M.frozen(cr)): v = o
        else:
            v = o
            sl = self.L.steps(cl); sr = self.R.steps(cr)
            assert [l for l, _ in sl] == [l for l, _ in sr]
            for (lab, tl), (_, tr) in zip(sl, sr):
                right = {classical(x): (q, x) for q, x in tr}
                b = F(1)
                for p, x in tl:
                    k = classical(x)
                    if k in right:
                        q, y = right[k]; w = min(p, q)
                        b += w * self.u(x, y) - w
                v = max(v, b)
                if v == 1: break
        self.memo[key] = v
        return v

CASES = [('phase', str(e), M.Zone(), M.Zone(eps=e)) for e in (F(0), F(1, 100), F(1, 40), F(1, 20))]
CASES.append(('bath_reset', 'report-tick reset', M.Zone(), M.Zone(reset=True)))

def run(N, system, out, only=None):
    rows = []
    for name, par, zl, zr in CASES:
        if only and par not in only: continue
        t = time.time()
        if system:   # (Ctrl_1 || Ctrl_2 || Mon) \ {c_1,c_2}; only zone 1 differs
            L = M.System([zl, M.Zone()], True); R = M.System([zr, M.Zone()], True)
        else:        # the open component Ctrl_1
            L = M.System([zl], False); R = M.System([zr], False)
        c = Cert(L, R); v = c.u(L.init(N), R.init(N))
        rows.append(dict(experiment=name, cycles=N, parameter=par, system=system,
                         upper_exact=str(v), upper_display=float(v), pairs=len(c.memo),
                         seconds=time.time() - t))
        print(N, 'system' if system else 'component', par, float(v), len(c.memo),
              round(time.time() - t, 1), flush=True)
    path = Path(__file__).parent / out
    old = json.loads(path.read_text()) if path.exists() else []
    keys = {(r['cycles'], r['parameter'], r['system']) for r in rows}
    path.write_text(json.dumps([r for r in old if (r['cycles'], r['parameter'], r['system'])
                                not in keys] + rows, indent=2) + '\n')

if __name__ == '__main__':
    # usage: certify.py N component|system [parameter ...]
    args = sys.argv[1:]
    run(int(args[0]) if args else 1, len(args) > 1 and args[1] == 'system', 'results.json',
        set(args[2:]) or None)
