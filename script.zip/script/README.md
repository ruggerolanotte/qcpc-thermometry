# Quantum thermometry scripts

Run all commands from the `script/` directory. Output files are written to `thermometry/`.

## Run everything

Install NumPy for the matrix checks, then run:

python3 -m pip install numpy
python3 thermometry/runall.py


The runner executes the experiments and checks, then generates the manuscript table. The two-decision calculations can take substantially longer than the one-decision calculations.

Other runner commands:

python3 thermometry/runall.py --list  # Print the commands without running them
python3 thermometry/runall.py checks  # Run validation checks only
python3 thermometry/runall.py quick   # Run the checks and jitter calculation
python3 thermometry/runall.py table   # Generate the table from existing results


Optional: install `gmpy2` and run `python3 thermometry/runall.py --gmp` to use GMP rational arithmetic.


## Parameters

- N: number of control decisions. Use '1' or '2' for component distances and '1', '2' or '3' for component upper bounds.
- Phase parameter: `0`, `1/100`, `1/40` or `1/20`. Use `'report-tick reset'` for the environmental-reset comparison. Omitting the comparison runs all cases.
TARGET (certify.py only): Use 'component' to compute an upper bound for one zone, or 'system' to compute an upper bound directly for the monitored two-zone system. In the system comparisons, only zone 1 is perturbed.
- `parameters.json`: phase lookup table and physical parameters.


## Individual commands


**Component distances.** Write certified lower and upper endpoints to `exact_results.json`:

python3 thermometry/exact.py 1
python3 thermometry/exact.py 2


To run just one comparison:

python3 thermometry/exact.py 2 1/20
python3 thermometry/exact.py 2 'report-tick reset'



**Upper certificates.** Write the component and monitored-system bounds to `results.json`. The final command runs only the zero-error monitored baseline for two decisions:

python3 thermometry/certify.py 1 component
python3 thermometry/certify.py 2 component
python3 thermometry/certify.py 3 component
python3 thermometry/certify.py 1 system
python3 thermometry/certify.py 2 system 0



**Environmental coherence.** Print the distances for the persistent and reset plants for one and two decisions:

python3 thermometry/coherence.py 1 2



**Actuator delay.** Write the comparisons for one- and two-tick delays to `latency_results.json`:

python3 thermometry/latency.py



**Thermal jitter.** Write the selected trajectories, alignment and timed distance to `jitter_results.json`:

python3 thermometry/jitter.py



**Manuscript table.** Generate `bounds.tex` for one and two decisions from `exact_results.json` and `results.json`:

python3 thermometry/make_table.py



**Validation.** These commands print their results to the terminal. The latency check reads the supplied or regenerated `latency_results.json`:

python3 thermometry/check.py          # Quantum operations and thermal probabilities; requires NumPy

python3 thermometry/test_dual.py      # Two-atom optimisation against rational linear programs

python3 thermometry/exact.py --check  # Transport checks on protocol transitions and memory witness

python3 thermometry/check_latency.py  # Delay transitions, command histories and alignments



**Imported modules.** `model.py` defines the model and observation cost; `arithmetic.py` selects the rational arithmetic backend. Neither requires a separate command.
